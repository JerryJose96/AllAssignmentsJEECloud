package com.cg.tma.service;

import java.util.List;

import com.cg.tma.entities.Trainee;

public interface TraineeService {
	List<Trainee> getAllTrainees();
	void insertTrainee(Trainee trainee);
	void deleteTrainee(Integer tId);
	void modifyTrainee(Trainee trainee);
	Trainee getOneTrainee(Integer tId);
}
