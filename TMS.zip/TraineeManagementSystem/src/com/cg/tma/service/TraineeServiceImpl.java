package com.cg.tma.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.tma.dao.TraineeDao;
import com.cg.tma.entities.Trainee;

@Transactional
@Service
public class TraineeServiceImpl implements TraineeService {
	@Autowired
	TraineeDao tdao;
	
	@Override
	public List<Trainee> getAllTrainees() {
		return tdao.fetchAllTrainees();
	}

	@Override
	public void insertTrainee(Trainee trainee) {
		tdao.insertTrainee(trainee);
		
	}

	@Override
	public void deleteTrainee(Integer tId) {
		tdao.deleteTrainee(tId);
		
	}

	@Override
	public void modifyTrainee(Trainee trainee) {
		tdao.modifyOneTrainee(trainee);
		
	}

	@Override
	public Trainee getOneTrainee(Integer tId) {
		return tdao.getOneTrainee(tId);
	}

}
