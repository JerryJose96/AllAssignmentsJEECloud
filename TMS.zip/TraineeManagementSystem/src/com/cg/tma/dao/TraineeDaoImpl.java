package com.cg.tma.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.tma.entities.Trainee;

@Repository
public class TraineeDaoImpl implements TraineeDao {
	@PersistenceContext
	private EntityManager em;
	
	@Override
	public List<Trainee> fetchAllTrainees() {
		String jpql = "SELECT t FROM Trainee t";
		TypedQuery<Trainee> query = em.createQuery(jpql,Trainee.class);
		return query.getResultList();
	}

	@Override
	public void insertTrainee(Trainee trainee) {
		em.persist(trainee);	
	}

	@Override
	public Trainee getOneTrainee(Integer tId) {
		return em.find(Trainee.class, tId);
	}

	@Override
	public void modifyOneTrainee(Trainee trainee) {
		em.merge(trainee);
	}

	@Override
	public void deleteTrainee(Integer tId) {
		Trainee trainee = em.find(Trainee.class, tId);
		em.remove(trainee);		
	}

}
