package com.cg.tma.dao;

import java.util.List;

import com.cg.tma.entities.Trainee;

public interface TraineeDao {
	List<Trainee> fetchAllTrainees();
	void insertTrainee(Trainee trainee);
	Trainee getOneTrainee(Integer tId);
	void modifyOneTrainee(Trainee trainee);
	void deleteTrainee(Integer tId);
}
