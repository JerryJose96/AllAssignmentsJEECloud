package com.cg.tma.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.tma.entities.Admin;
import com.cg.tma.entities.Trainee;
import com.cg.tma.service.TraineeService;

@Controller
public class TraineeController {
	@Autowired
	TraineeService tser;
	Trainee trainee1 = null;
	@RequestMapping("start")
	public String showMain(Model model){
		Admin admin = new Admin();
		model.addAttribute("admin",admin);
		return "login";
	}
	@RequestMapping("login")
	public String showLogin(@Valid@ModelAttribute("admin")Admin admin,BindingResult res,Model model){
		if(res.hasErrors()){
			model.addAttribute("admin",admin);
			return "login";
		}
		else{
			if(admin.getuName().equals("jerry.jose")&& admin.getPwd().equals("jerry")){
				return "operation";
			}
			else{
				return "login";
			}
		}
	}
	@RequestMapping("option1")
	public String opt1(Model model){
		Trainee trainee = new Trainee();
		model.addAttribute("trainee",trainee);
		return "AddTrainee";
	}
	@RequestMapping("add")
	public String addTrainee(@ModelAttribute("trainee")Trainee trainee,BindingResult res,Model model){
		if(res.hasErrors()!=true){
			tser.insertTrainee(trainee);
			model.addAttribute("trainee",trainee);
			return "AddSuccess";}
		else
			return "AddTrainee";
	}
	@RequestMapping("option5")
	public String opt5(Model model){
		List<Trainee> tList = tser.getAllTrainees();
		model.addAttribute("tList",tList);
		return "AllTrainees";
	}
	@RequestMapping("option4")
	public String opt4(Model model){
		Trainee trainee = new Trainee();
		model.addAttribute("trainee",trainee);
		model.addAttribute("flag",false);
		return "showOneTrainee";
	}
	@RequestMapping("showOneTrainee")
	public String retOneTrainee(@RequestParam("flag")Boolean flag,@ModelAttribute("trainee")Trainee trainee,BindingResult res,Model model){
		if(res.hasErrors()){
			model.addAttribute("trainee",trainee);
			model.addAttribute("false",false);
			return "showOneTrainee";
		}
		else{
			Trainee train = tser.getOneTrainee(trainee.getTraineeId());
			model.addAttribute("flag",true);
			model.addAttribute("train",train);
			return "showOneTrainee";
		}
	}
	@RequestMapping("option3")
	public String opt3(Model model){
		Trainee trainee = new Trainee();
		model.addAttribute("trainee",trainee);
		model.addAttribute("flag",false);
		return "modifyOne";
	}
	@RequestMapping("modifyOne")
	public String modifyOne(@ModelAttribute("trainee")Trainee trainee,BindingResult res,Model model){
		if(res.hasErrors()){
			model.addAttribute("trainee",trainee);
			model.addAttribute("flag",false);
			return "modifyOne";
		}
		else{
			//tser.modifyTrainee(trainee);
			Trainee train = tser.getOneTrainee(trainee.getTraineeId());
			model.addAttribute("train",train);
			model.addAttribute("flag",true);
			return "modifyOne";
		}
	}
	@RequestMapping("modify")
	public String modify(@ModelAttribute("trainee")Trainee trainee,BindingResult res,Model model){
		if(res.hasErrors()){
			model.addAttribute("trainee",trainee);
			return "modifyOne";
		}
		else{
			tser.modifyTrainee(trainee);
			return "AddSuccess";
		}
	}
	@RequestMapping("option2")
	public String opt2(Model model){
		Trainee trainee = new Trainee();
		model.addAttribute("trainee",trainee);
		return "deleteTrainee";
	}
	@RequestMapping("deleteOne")
	public String deleteOne(@ModelAttribute("trainee")Trainee trainee,BindingResult res,Model model){
		if(res.hasErrors()){
			model.addAttribute("trainee",trainee);
			model.addAttribute("flag",false);
			return "deleteTrainee";
		}
		else{
			//tser.modifyTrainee(trainee);
			trainee1 = tser.getOneTrainee(trainee.getTraineeId());
			model.addAttribute("train",trainee1);
			model.addAttribute("flag",true);
			return "deleteTrainee";
		}
	}
	@RequestMapping("delete")
	public String delete(@ModelAttribute("trainee")Trainee trainee,BindingResult res,Model model){
		if(res.hasErrors()){
			model.addAttribute("trainee",trainee);
			return "deleteTrainee";
		}
		else{
			tser.deleteTrainee(trainee1.getTraineeId());
			return "deleteTraineeSuccess";
		}
	}
	
}
