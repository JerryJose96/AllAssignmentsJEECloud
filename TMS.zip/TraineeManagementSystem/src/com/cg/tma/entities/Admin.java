package com.cg.tma.entities;

import javax.validation.constraints.NotNull;


public class Admin {
	
	@NotNull(message="Can't be NULL")
	private String uName;
	
	@NotNull(message="Can't be NULL")
	private String pwd;
	public Admin() {
	}
	public String getuName() {
		return uName;
	}
	public void setuName(String uName) {
		this.uName = uName;
	}
	public String getPwd() {
		return pwd;
	}
	public void setPwd(String pwd) {
		this.pwd = pwd;
	}
	@Override
	public String toString() {
		return "Admin [uName=" + uName + ", pwd=" + pwd + "]";
	}
	
}
