import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class SortProduct {

	public static void main(String[] args) {
		/*String[] product = new String[5];
		String temp;

		product[0] = "Heli";
		product[1] = "Bicycle";
		product[2] = "Video Game";
		product[3] = "Car";
		product[4] = "Scooter";
		
		System.out.println("Products after sorting");
		for (int i = 0; i < product.length; i++) 
		{
			for (int j = i+1; j < product.length; j++) 
			{
				if (product[j].compareTo(product[i])<0) {
					temp = product[j];
					product[j] = product[i];
					product[i] = temp;
				}
			}
		}
		for(String prod1:product) {
			System.out.println(prod1);
		}
		*/
		ArrayList<String> product = new ArrayList<String>();
		System.out.println("Enter the no. of products");
		Scanner sc = new Scanner(System.in);
		int num = sc.nextInt();
		
		for (int i=0;i <= num; i++) {
			String prod = sc.nextLine();
			product.add(prod);
		}
		Collections.sort(product);
		
		for(String pr:product) {
			System.out.println(pr);
		}
	}
	
}
