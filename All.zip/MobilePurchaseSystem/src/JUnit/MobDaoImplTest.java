package JUnit;

import static org.junit.Assert.*;

import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;

import com.cg.mps.dto.Mobile;
import com.cg.mps.exception.MobileException;
import com.cg.mps.service.AllServicesImpl;

import junit.framework.Assert;

public class MobDaoImplTest {
	static AllServicesImpl ASI= null;
	static Mobile mob1 = null;
	@BeforeClass
	public static void setUp() {
		ASI = new AllServicesImpl();
		mob1 = new Mobile(1008,"Oppo F1",10000,"15");
		System.out.println("setUp is called");
	}
	@Test
	public void insMobTest() throws MobileException {
		int done = ASI.insMob(mob1);
				Assert.assertEquals(1, done);
	
	}
	@Test
	public void serMobTest() throws MobileException {
		int done = ASI.searchMob(15000,20000);
		Assert.assertEquals(2, done);
	}
}
