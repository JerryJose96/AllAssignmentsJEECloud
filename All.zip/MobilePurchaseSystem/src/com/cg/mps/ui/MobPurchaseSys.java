package com.cg.mps.ui;

import java.sql.Date;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Scanner;

import com.cg.mps.dto.Mobile;
import com.cg.mps.dto.PurchaseDetails;
import com.cg.mps.exception.MobileException;
import com.cg.mps.service.AllServices;
import com.cg.mps.service.AllServicesImpl;

public class MobPurchaseSys {
	static AllServices AS = null;
	static Scanner sc = null;
	static int purID= 1501;
	public static void main(String[] args) {
		System.out.println("************ Welcome to Mobile Purchase System *************");
		sc = new Scanner(System.in);
		AS = new AllServicesImpl();
		int choice = 0;
		while(true) {
			System.out.println("\tEnter 1. To View Mobiles\n"
					+ "2. Delete a Mobile from Mobiles\n"
					+ "3. Search Mobiles based on a price range\n"
					+ "4. Insert Customer Details\n"
					+ "5. Insert Mobile Details");
			choice = sc.nextInt();
			switch(choice) {
			case 1: dispAllMob();break;
			case 2: delMob();break;
			case 3: serMob();break;
			case 4: insCust();break;
			case 5: insMob();break;
			default: System.exit(1);
			}
		}
	}
	private static void insMob() {
		Scanner sc1,sc2,sc3;
		sc1 = new Scanner(System.in);
		System.out.println("Enter the Mobile ID");
		int id = sc.nextInt();
		System.out.println("Enter the Mobile Name");
		String name = sc1.nextLine();
		System.out.println("Enter the Mobile Price");
		sc2 = new Scanner(System.in);
		int price = sc2.nextInt();
		System.out.println("Enter the Mobile Quantity");
		sc3 = new Scanner(System.in);
		String quant = sc3.next();
		Mobile mob = new Mobile(id,name,price,quant);
		try {
			int done = AS.insMob(mob);
			if(done==1) {
				System.out.println("Data has been inserted");
			}
			else {
				System.out.println("Data couldn't be inserted");
			}
		} catch (MobileException e) {
			e.printStackTrace();
		}
	}
	private static void insCust() {
		try {
			System.out.println("Enter Mobile ID of the Mobile you wanna buy");
			int id = sc.nextInt();
			if(AS.validateMID(id)) {
				if(AS.validateQuantity(id)) {
					System.out.println("Enter your Name");
					String name = sc.next();
					if(AS.validateCustName(name)) {
						System.out.println("Enter your Mail ID");
						String mail = sc.next();
						if(AS.validateMailID(mail)) {
							System.out.println("Enter your Phone No.");
							String phone = sc.next();
							if(AS.validatePhoneNo(phone)) {
								Date custDate = Date.valueOf(LocalDate.now());
								PurchaseDetails pd = new PurchaseDetails(1,name,mail,phone,custDate,id);
								//purID = purID+2;
								int done = AS.insCust(pd);
								if(done==1) {
									AS.updateMob(pd);
								}
							}
						}
					}
				}
			}
		}catch(Exception e) {
			e.printStackTrace();
		}

	}
	private static void serMob() {
		try {
			System.out.println("Enter the lower price");
			int low = sc.nextInt();
			System.out.println("Enter the higher price");
			int high = sc.nextInt();
			AS.searchMob(low,high);
		} catch (MobileException e) {
			e.printStackTrace();
		}

	}
	private static void delMob() {
		try {
			int done = AS.deleteMob();
			if (done==1) {
				System.out.println("Data is deleted");
			}
			else {
				System.out.println("Data couldn't be deleted");
			}
		} catch (MobileException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
	private static void dispAllMob() {
		ArrayList<Mobile> mobList = new ArrayList<Mobile>();
		try {
			mobList = AS.getAllMobiles();
			System.out.println("\tMOBILE ID \tNAME \tPRICE \tQUANTITY");
			for (Mobile mob:mobList) {
				System.out.println("\t" +mob.getmId()+"\t"+
						mob.getmName()+"\t"+
						mob.getmPrice()+"\t"+
						mob.getmQuantity());
			}
		}catch (MobileException e) {
			e.printStackTrace();
		}
	}

}
