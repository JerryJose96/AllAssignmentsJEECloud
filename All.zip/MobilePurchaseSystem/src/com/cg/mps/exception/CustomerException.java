package com.cg.mps.exception;

public class CustomerException extends Exception{
	String msg;
	static ErrorCode code;
	public CustomerException(String msg) {
		super(msg);
	}
	public CustomerException(String msg,
	Throwable cause,ErrorCode code) {
		super(msg,cause);
		this.code  = code;
	}
}
