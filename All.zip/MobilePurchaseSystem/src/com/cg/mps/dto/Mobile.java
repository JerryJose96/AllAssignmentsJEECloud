package com.cg.mps.dto;

public class Mobile {
	private int mId;
	private String mName;
	private int mPrice;
	private String mQuantity;
	public Mobile() {
		super();
	}
	public Mobile(int mId,String mName,int mPrice,String mQuantity) {
		super();
		this.mId = mId;
		this.mName = mName;
		this.mPrice = mPrice;
		this.mQuantity = mQuantity;
	}
	public int getmId() {
		return mId;
	}
	public void setmId(int mId) {
		this.mId = mId;
	}
	public String getmName() {
		return mName;
	}
	public void setmName(String mName) {
		this.mName = mName;
	}
	public int getmPrice() {
		return mPrice;
	}
	public void setmPrice(int mPrice) {
		this.mPrice = mPrice;
	}
	public String getmQuantity() {
		return mQuantity;
	}
	public void setmQuantity(String mQuantity) {
		this.mQuantity = mQuantity;
	}
	@Override
	public String toString() {
		return "Mobile [mId=" + mId + ", mName=" + mName + ", mPrice=" + mPrice + ", mQuantity=" + mQuantity + "]";
	}
}
