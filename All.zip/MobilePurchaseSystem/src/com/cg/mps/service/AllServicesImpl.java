package com.cg.mps.service;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.regex.Pattern;

import com.cg.mps.dao.CustDaoImpl;
import com.cg.mps.dao.MobDaoImpl;
import com.cg.mps.dto.Mobile;
import com.cg.mps.dto.PurchaseDetails;
import com.cg.mps.exception.CustomerException;
import com.cg.mps.exception.MobileException;
import com.cg.mps.util.DBUtil;

public class AllServicesImpl implements AllServices{
	MobDaoImpl mDI = null;
	CustDaoImpl cDI = null;
	public AllServicesImpl() {
		mDI = new MobDaoImpl();
		cDI = new CustDaoImpl();
	}
	@Override
	public ArrayList<Mobile> getAllMobiles() throws MobileException {
		return mDI.getAllMobiles();
	}
	@Override
	public int insMob(Mobile mob) throws MobileException {
		return mDI.insMob(mob);
	}

	@Override
	public int deleteMob() throws MobileException {
		return mDI.deleteMob();
	}
	@Override
	public int searchMob(int low,int high) throws MobileException {
		return mDI.searchMob(low,high);
	}
	@Override
	public int insCust(PurchaseDetails pd) throws CustomerException {
		return cDI.insCust(pd);
	}
	@Override
	public boolean validateQuantity(int mId) throws MobileException {
		int quant = 0;
		String q1 = null;
		Connection con = null;
		Statement st = null;
		ResultSet rs = null;
		try {
			con = DBUtil.getConn();
			String selectqry = "SELECT quantity FROM mobiles WHERE mobileid="+mId;
			st=con.createStatement();
			rs=st.executeQuery(selectqry);
			while(rs.next()) {
				q1 = rs.getString("quantity");
			}
		} catch (SQLException | IOException e) {
			e.printStackTrace();
		}
		quant = Integer.parseInt(q1);
		if (quant<0) {
			throw new MobileException("We dont have the anymore items left for the mobile ID entered");
		}
		else {
			return true;
		}
	}
	@Override
	public boolean validateCustName(String cName) throws CustomerException {
		String namePattern = "[A-Z][a-z]{1,20}";
		if(Pattern.matches(namePattern, cName)) {
			return true;
		}
		else {
			throw new CustomerException("Invalid Employee Name.Should start with CAPS ONLY.20 characters only allowed");
		}
	}
	@Override
	public boolean validateMailID(String cMail) throws CustomerException {
		String mailPattern = "[A-Za-z0-9._%+-]+@[A-Za-z]+[.][A-Za-z]{1,3}";
		if(Pattern.matches(mailPattern, cMail)) {
			return true;
		}
		else {
			throw new CustomerException("Invalid email ID");
		}
	}
	@Override
	public boolean validateMID(int mID) throws MobileException {
		Connection con = null;
		Statement st = null;
		ResultSet rs = null;
		try {
			con = DBUtil.getConn();
			String selectqry = "SELECT * FROM mobiles WHERE mobileid="+mID;
			st=con.createStatement();
			rs=st.executeQuery(selectqry);
		}
		catch(Exception e) {
			e.printStackTrace();
			throw new MobileException(e.getMessage());
		}
		if(rs==null) {
			throw new MobileException("There is no Mobile with this MobileID");
		}
		else {
			return true;
		}
	}
	@Override
	public boolean validatePhoneNo(String phone) throws CustomerException {
		String phonePattern = "[0-9]{10}";
		if(Pattern.matches(phonePattern, phone)) {
			return true;
		}
		else {
			throw new CustomerException("Phone no. should be 10 digits max");
		}
	}
	@Override
	public int updateMob(PurchaseDetails mob) throws CustomerException {
		return cDI.updateMob(mob);
	}
}
