package com.cg.mps.service;

import java.util.ArrayList;

import com.cg.mps.dto.Mobile;
import com.cg.mps.dto.PurchaseDetails;
import com.cg.mps.exception.CustomerException;
import com.cg.mps.exception.MobileException;

public interface AllServices {
	public ArrayList<Mobile> getAllMobiles() throws
	MobileException;
	public int insMob(Mobile mob) throws
	MobileException;
	public int updateMob(PurchaseDetails mob) throws
	CustomerException;
	public int deleteMob() throws
	MobileException;
	public int searchMob(int low,int high) throws
	MobileException;
	public int insCust(PurchaseDetails pd) throws
	CustomerException;
	public boolean validateQuantity(int mId) throws
	MobileException;
	public boolean validateCustName(String cName) throws
	CustomerException;
	public boolean validateMailID(String cMail) throws
	CustomerException;
	public boolean validateMID(int mID) throws
	MobileException;
	public boolean validatePhoneNo(String phone) throws
	CustomerException;
}
