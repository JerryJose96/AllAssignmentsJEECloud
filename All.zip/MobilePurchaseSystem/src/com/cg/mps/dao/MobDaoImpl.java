package com.cg.mps.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Scanner;

import org.apache.log4j.PropertyConfigurator;

import com.cg.mps.dto.Mobile;
import com.cg.mps.dto.PurchaseDetails;
import com.cg.mps.exception.MobileException;
import com.cg.mps.util.DBUtil;

public class MobDaoImpl implements MobDao{
	Connection con = null;
	Statement st = null;
	PreparedStatement pst = null;
	ResultSet rs = null;
	public MobDaoImpl() {
		PropertyConfigurator.configure("resources/log4j.properties");
	}
	@Override
	public int insMob(Mobile mob) throws MobileException {
		int data;
		try {
			con = DBUtil.getConn();
			String insertQuery = "INSERT INTO mobiles VALUES(?,?,?,?)";
			pst = con.prepareStatement(insertQuery);
			pst.setInt(1, mob.getmId());
			pst.setString(2, mob.getmName());
			pst.setInt(3, mob.getmPrice());
			pst.setString(4, mob.getmQuantity());
			data = pst.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
			throw new MobileException(e.getMessage());
		}
		return data;
	}

	@Override
	public ArrayList<Mobile> getAllMobiles() throws MobileException {
		ArrayList<Mobile> mobList = null;
		try {
			con = DBUtil.getConn();
			mobList = new ArrayList<Mobile>();
			String selectqry = "SELECT * FROM mobiles";
			st=con.createStatement();
			rs=st.executeQuery(selectqry);
			while(rs.next()) {
				mobList.add(new Mobile(rs.getInt("mobileid"),
						rs.getString("name"),
						rs.getInt("price"),
						rs.getString("quantity")));
			}
		}catch(Exception e) {
			throw new MobileException(e.getMessage());
		}
		finally {
			try {
				st.close();
				rs.close();
				con.close();
			}catch(SQLException e) {
				throw new MobileException(e.getMessage());
			}
		}
		return mobList;
	}

	@Override
	public int deleteMob() throws MobileException {
		int data;
		try {
			con = DBUtil.getConn();
			System.out.println("Enter the Mobile ID of the phone you want to delte: ");
			Scanner sc = new Scanner(System.in);
			int mobId = sc.nextInt();
			String delQuery = "DELETE FROM mobiles WHERE mobileid=?";
			pst = con.prepareStatement(delQuery);
			pst.setInt(1,mobId);
			data = pst.executeUpdate();
		}
		catch(Exception e) {
			e.printStackTrace();
			throw new MobileException(e.getMessage());
		}
		return data;
	}

	@Override
	public int searchMob(int low,int high) throws MobileException {
		int data = 0;
		Scanner sc = new Scanner(System.in);
		try {
			//System.out.println("Enter the lower price");
			//int low = sc.nextInt();
			//System.out.println("Enter the higher price");
			//int high = sc.nextInt();
			con = DBUtil.getConn();
			String searchQuery = "SELECT * FROM mobiles WHERE PRICE>=? AND PRICE<=?";
			pst = con.prepareStatement(searchQuery);
			pst.setInt(1, low);
			pst.setInt(2, high);
			data = pst.executeUpdate();
			rs = pst.executeQuery();
			while(rs.next()) {
				System.out.println("MOBILE ID: "+rs.getInt("mobileid")+"\t"+
						"NAME: "+rs.getString("name")+"\t"+
								"PRICE: "+rs.getInt("price")+"\t"+
						"QUANTITY: "+rs.getInt("quantity"));
			}
		}
		catch(Exception e) {
			e.printStackTrace();
			throw new MobileException(e.getMessage());
		}
		return data;
	}

}
