package com.cg.mps.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import org.apache.log4j.PropertyConfigurator;

import com.cg.mps.dto.PurchaseDetails;
import com.cg.mps.exception.CustomerException;
import com.cg.mps.exception.MobileException;
import com.cg.mps.util.DBUtil;

public class CustDaoImpl implements CustDao{
	Connection con = null;
	Statement st = null;
	PreparedStatement pst = null;
	PreparedStatement pst1 = null;
	ResultSet rs = null;
	ResultSet rs1 = null;
	int quant;
	public CustDaoImpl() {
		PropertyConfigurator.configure("resources/log4j.properties");
	}
	@Override
	public int insCust(PurchaseDetails pd) throws CustomerException {
		int data;
		try {
			con = DBUtil.getConn();
			String insertQuery = "INSERT INTO purchasedetails VALUES(seq_pid.nextval,?,?,?,?,?)";
			pst = con.prepareStatement(insertQuery);
			//pst.setInt(1, pd.getPurchaseId());
			pst.setString(1, pd.getcName());
			pst.setString(2, pd.getMailId());
			pst.setString(3, pd.getPhoneNo());
			pst.setDate(4, pd.getPurchaseDate());
			pst.setInt(5, pd.getMobileId());
			data = pst.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
			throw new CustomerException(e.getMessage());
		}
		return data;
	}
	@Override
	public int updateMob(PurchaseDetails pd) throws CustomerException {
		int data;
		try {
			con = DBUtil.getConn();
			String searchQuery = "SELECT * FROM mobiles WHERE mobileid=?";
			pst = con.prepareStatement(searchQuery);
			pst.setInt(1, pd.getMobileId());
			rs = pst.executeQuery();
			while(rs.next()) {
				quant = Integer.parseInt(rs.getString("quantity"));
			}
			quant=quant-1;
			pst.close();
			String quant1 = Integer.toString(quant);
			//con = DBUtil.getConn();
			String updateQuery = "UPDATE mobiles SET quantity=? WHERE mobileid=?";
			pst = con.prepareStatement(updateQuery);
			pst.setString(1, quant1);
			pst.setInt(2, pd.getMobileId());
			data = pst.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
			throw new CustomerException(e.getMessage());
		}
		return 0;
	}

}
