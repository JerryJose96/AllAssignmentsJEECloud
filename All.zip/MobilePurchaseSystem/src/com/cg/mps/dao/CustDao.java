package com.cg.mps.dao;

import java.util.ArrayList;

import com.cg.mps.dto.PurchaseDetails;
import com.cg.mps.exception.CustomerException;
import com.cg.mps.exception.MobileException;

public interface CustDao {
	public int insCust(PurchaseDetails pd) throws
	CustomerException;
	public int updateMob(PurchaseDetails mob) throws
	CustomerException;
	/*public int updateCust(PurchaseDetails pd) throws
	CustomerException;
	public ArrayList<PurchaseDetails> getAllCust() throws
	CustomerException;
	public int deleteCust(PurchaseDetails pd) throws
	CustomerException;
	public int searchCust(PurchaseDetails pd) throws
	CustomerException;*/
}
