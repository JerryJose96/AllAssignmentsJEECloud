package com.cg.mps.dao;

import java.util.ArrayList;

import com.cg.mps.dto.Mobile;
import com.cg.mps.dto.PurchaseDetails;
import com.cg.mps.exception.MobileException;

public interface MobDao {
	public int insMob(Mobile mob) throws
	MobileException;
	public ArrayList<Mobile> getAllMobiles() throws
	MobileException;
	public int deleteMob() throws
	MobileException;
	public int searchMob(int low,int high) throws
	MobileException;
}
