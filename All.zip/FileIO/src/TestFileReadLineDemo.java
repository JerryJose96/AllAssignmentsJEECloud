import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class TestFileReadLineDemo {

	public static void main(String[] args) {
		File myFile = new File("D://Jerry Jose/FileIO/src/TestEmployeeReadDemo.java");
		FileReader fis = null;
		FileWriter fw = null;
		BufferedReader br = null;
		BufferedWriter bw = null;
		try {
			fis = new FileReader(myFile);
			br = new BufferedReader(fis);
			fw = new FileWriter("MyFile.txt");
			bw = new BufferedWriter(fw);
			String line = br.readLine();
			while(line!=null) {
				System.out.println(line);
				bw.write(line);
				bw.flush();
				line = br.readLine();
			}
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

}
