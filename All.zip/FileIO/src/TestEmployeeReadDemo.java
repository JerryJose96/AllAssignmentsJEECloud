import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class TestEmployeeReadDemo {

	public static void main(String[] args) {
		try {
		InputStreamReader isr = new InputStreamReader(System.in);
		BufferedReader br = new BufferedReader(isr);
		System.out.println("Enter emp id: ");
		int id = Integer.parseInt(br.readLine());
		System.out.println("Enter your name: ");
		String name = br.readLine();
		System.out.println("Enter salary: ");
		float sal = Float.parseFloat(br.readLine());
		System.out.println("ID: " + id);
		System.out.println("Name: " + name);
		System.out.println("Salary: " + sal);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
