import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.Scanner;

public class TestEmpSerializationDemo {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Emp id: ");
		int id =sc.nextInt();
		System.out.println("Enter Emp name: ");
		String name =sc.next();
		System.out.println("Enter Emp salary: ");
		float sal =sc.nextFloat();
		
		Employee e1 = new Employee(id,name,sal);
		FileOutputStream fos = null;
		ObjectOutputStream oos = null;
		try {
			fos = new FileOutputStream("EmpObj.obj");
			oos = new ObjectOutputStream(fos); 
			oos.writeObject(e1);
			System.out.println("Employee e1 is written in the file");
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
