import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

import com.cg.eis.bean.Employee;
import com.cg.eis.service.Service;

public class TenTwo {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter how many employee details you wanna enter");
		int num = sc.nextInt();
		Connection  con = null;
		String insertQuery = "INSERT INTO emp1_157529(emp_id,emp_name,emp_salary,emp_designation,emp_insurance) VALUES(?,?,?,?,?)";
		PreparedStatement pst = null;
		Statement st = null;
		ResultSet rs = null;
		int data = 0;
		
		Employee emp[] = new Employee[num];
		for (int i=0;i<num;i++) {
			emp[i] = new Employee();
			System.out.println("Enter Emp ID: ");
			int id = sc.nextInt();
			System.out.println("Enter Emp Name: ");
			String name = sc.next();
			System.out.println("Enter Emp Salary: ");
			Double sal = sc.nextDouble();
			emp[i].setId(id);
			emp[i].setName(name);
			emp[i].setSalary(sal);
			Service s = new Service();
			s.method1(emp[i]);
			s.method2(emp[i]);
			//inserting into table emp1_157529
			try {
				Class.forName("oracle.jdbc.driver.OracleDriver");
				try {
					con = DriverManager.getConnection("jdbc:oracle:thin:@10.51.103.201:1521:ORCL11G","lab1btrg34","lab1boracle");
					pst = con.prepareStatement(insertQuery);
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				try {
					pst.setInt(1,emp[i].getId());
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				try {
					pst.setString(2,emp[i].getName());
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				Double sal1 = new Double(emp[i].getSalary());
				int sal11 = sal1.intValue();
				try {
					pst.setInt(3,sal11);
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				try {
					String des = emp[i].getDesignation();
					pst.setString(4,des);
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				try {
					String ins = emp[i].getInsuranceScheme();
					pst.setString(5, ins);
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				try {
					data = pst.executeUpdate();
					System.out.println(data + "data is inserted in table");
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		try {
			st = con.createStatement();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			rs = st.executeQuery("SELECT * FROM emp1_157529");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			while(rs.next()) {
				System.out.println("ID: " + rs.getInt("emp_id") + ", Name: " + rs.getString("emp_name") + ", Salary: " +
						rs.getInt("emp_salary") + ", Desig.: " + rs.getString("emp_designation") +
				", Ins. Scheme: " + rs.getString("emp_insurance"));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//deleting 
		System.out.println("Enter ID no. to delete the record");
		int idDel = sc.nextInt();
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			try {
				con = DriverManager.getConnection("jdbc:oracle:thin:@10.51.103.201:1521:ORCL11G","lab1btrg34","lab1boracle");
				String query = "DELETE FROM emp1_157529 WHERE emp_id="+idDel;
				pst = con.prepareStatement(query);
				pst.executeUpdate();
				System.out.println("Deleted 1 entry");
			} catch (SQLException e) {
				e.printStackTrace();
			}
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}

}
