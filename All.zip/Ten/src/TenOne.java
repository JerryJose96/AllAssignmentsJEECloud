import java.io.FileInputStream;
import java.io.IOException;
import java.util.Iterator;
import java.util.Properties;
import java.util.Scanner;
import java.util.Set;
import java.io.FileOutputStream;
public class TenOne {

	public static void main(String[] args) {
		FileOutputStream fos = null;
		FileInputStream fis = null;
		Properties myPros = null;
		String name = null;
		String id = null;
		System.out.println("Enter the id of the person: ");
		Scanner sc = new Scanner(System.in);
		id = sc.nextLine();
		System.out.println("Enter the name of the person: ");
		name = sc.nextLine();
		//System.out.println("Name: " + name);
		System.out.println("Enter the salary of the person: ");
		String salary = sc.nextLine();
		//System.out.println("Salary: " + salary);
		try {
			//writing to file
			fos = new FileOutputStream("PersonProps.properties");
			myPros = new Properties(); 
			myPros.setProperty("ID", id);
			myPros.setProperty("Name", name);
			myPros.setProperty("Salary", salary);
			myPros.store(fos, "This is Person Information");
			System.out.println("Data is written in the file");
			//reading from file
			fis = new FileInputStream("PersonProps.properties");
			//myPros = new Properties(); 
			myPros.load(fis);
			String readId = myPros.getProperty("ID");
			String readName = myPros.getProperty("Name");
			String readSalary = myPros.getProperty("Salary");
			System.out.println("Information: \n" + "ID: " + readId + ", 	Name:" + readName + ",	 Salary:" + readSalary);
			System.out.println("*******************");
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

}
