import static org.junit.Assert.*;

import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;

public class DateTest {
	static Date date = new Date();
	@BeforeClass
	public static void setUp() {
		System.out.println("setUp is call once" 
				+ " Before the execution of " +
				"all test cases");
		date.setDay(1);
		date.setMonth(11);
		date.setYear(1996);
	}
	@Test
	public void testDay() {
		Assert.assertEquals(1,date.getDay());
	}
	@Test
	public void testMonth() {
		Assert.assertEquals(11,date.getMonth());
	}
	@Test
	public void testYear() {
		Assert.assertEquals(1996,date.getYear());
	}


}
