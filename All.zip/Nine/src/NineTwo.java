import static org.junit.Assert.*;

import java.time.LocalDate;

import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;

import com.capgemini.person.Person;

public class NineTwo {
	static Person p1 = new Person();
	@BeforeClass
	public static void setUp() {
		System.out.println("setUp is called once");
		p1.setFirstName("Jerry");
		p1.setLastName("Jose");
		p1.setGender('M');
	}
	@Test
	public void testFirstName() {
		Assert.assertEquals("Jerry",p1.getFirstName());
	}
	@Test
	public void testLastName() {
		Assert.assertEquals("Jose",p1.getLastName());
	}
	@Test
	public void testGender() {
		String s = p1.getGender();
		char c = s.charAt(0);
		Assert.assertEquals('M',c);
	}
	@Test
	public void testFullName() {
		Assert.assertEquals("Jerry Jose",p1.getFullName("Jerry","Jose"));
	}

}
