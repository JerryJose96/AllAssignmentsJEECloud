import static org.junit.Assert.*;

import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.eis.bean.Employee;
import com.cg.eis.exception.*;

import junit.framework.Assert;

public class ExceptionCheck {
	EmployeeException empExcep = new EmployeeException();
	Employee e1 = null;
	
	@Test (expected=RuntimeException.class)
	public void testNullsInName()
		{
			empExcep.checkEmp(1500);		
		}


}
