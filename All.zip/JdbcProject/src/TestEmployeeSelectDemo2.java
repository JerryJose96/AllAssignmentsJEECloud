

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class TestEmployeeSelectDemo2 {

	public static void main(String[] args) {
		Connection con = null;
		PreparedStatement pst = null;
		ResultSet rs = null;
		String query = "SELECT * FROM emp_157529 WHERE emp_salary>=? AND emp_salary<=?";
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter minimum salary:");
		int min = sc.nextInt();
		System.out.println("Enter maximum salary:");
		int max = sc.nextInt();
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con = DriverManager.getConnection("jdbc:oracle:thin:@10.51.103.201:1521:ORCL11G","lab1btrg34","lab1boracle");
			pst = con.prepareStatement(query);
			pst.setInt(1,min);
			pst.setInt(2,max);
			rs = pst.executeQuery();
			while(rs.next()) {
				System.out.println("ID: " + rs.getInt("emp_id") + ", Name: " + rs.getString("emp_name") + ", Salary: " +
						rs.getInt("emp_salary"));
			}
			
		}
		catch(ClassNotFoundException e) {
			e.printStackTrace();
		}
		catch(SQLException e) {
			e.printStackTrace();
		}

	}

}
