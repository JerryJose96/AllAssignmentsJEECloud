import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class TestEmployeeInsertDemo {

	public static void main(String[] args) {
		Connection  con = null;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter emp id");
		int id = sc.nextInt();
		System.out.println("Enter emp name");
		String name = sc.nextLine();
		sc.nextLine();
		System.out.println("Enter emp salary");
		int sal = sc.nextInt();
		String insertQuery = "INSERT INTO emp_157529 VALUES(?,?,?)";
		PreparedStatement pst = null;
			try {
				try {
					Class.forName("oracle.jdbc.driver.OracleDriver");
				} catch (ClassNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				con = DriverManager.getConnection("jdbc:oracle:thin:@10.51.103.201:1521:ORCL11G","lab1btrg34","lab1boracle");
				pst = con.prepareStatement(insertQuery);
				pst.setInt(1,id);
				pst.setString(2,name);
				pst.setInt(3,sal);
				
				int data = pst.executeUpdate();
				System.out.println(data + "data is inserted in table");
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			

	}

}
