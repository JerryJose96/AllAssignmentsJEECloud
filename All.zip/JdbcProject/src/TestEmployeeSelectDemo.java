import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class TestEmployeeSelectDemo {

	public static void main(String[] args) {
		Connection con = null;
		Statement st = null;
		ResultSet rs = null;
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con = DriverManager.getConnection("jdbc:oracle:thin:@10.51.103.201:1521:ORCL11G","lab1btrg34","lab1boracle");
			st = con.createStatement();
			rs = st.executeQuery("SELECT * FROM emp_157529");
			while(rs.next()) {
				System.out.println("ID: " + rs.getInt("emp_id") + ", Name: " + rs.getString("emp_name") + ", Salary: " +
						rs.getInt("emp_salary"));
			}
			
		}
		catch(ClassNotFoundException e) {
			e.printStackTrace();
		}
		catch(SQLException e) {
			e.printStackTrace();
		}
	}

}
