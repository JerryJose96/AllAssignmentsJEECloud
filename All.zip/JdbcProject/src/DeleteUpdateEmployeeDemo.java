import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class DeleteUpdateEmployeeDemo {

	public static void main(String[] args) {
		Connection con = null;
		System.out.println("Enter \n1. Delete Record \n2. Update Record");
		Scanner sc = new Scanner(System.in);
		PreparedStatement pst = null;
		int rs = 0 ;
		int i = sc.nextInt();
		int id = 0;
		switch(i) {
		case 1:
			System.out.println("Enter ID no. to delete the record");
			id = sc.nextInt();
			try {
				Class.forName("oracle.jdbc.driver.OracleDriver");
				try {
					con = DriverManager.getConnection("jdbc:oracle:thin:@10.51.103.201:1521:ORCL11G","lab1btrg34","lab1boracle");
					String query = "DELETE FROM emp_157529 WHERE emp_id="+id;
					pst = con.prepareStatement(query);
					rs = pst.executeUpdate();
					System.out.println(rs);					
				} catch (SQLException e) {
					e.printStackTrace();
				}
			} catch (ClassNotFoundException e) {
				e.printStackTrace();
			}
		break;
		case 2:
			System.out.println("Enter ID no. to update the record");
			id = sc.nextInt();
			try {
				Class.forName("oracle.jdbc.driver.OracleDriver");
				try {
					con = DriverManager.getConnection("jdbc:oracle:thin:@10.51.103.201:1521:ORCL11G","lab1btrg34","lab1boracle");
					System.out.println("Enter name to update");
					Scanner sc1 = new Scanner(System.in);
					String name = sc1.nextLine();
					String query = "UPDATE emp_157529 SET emp_name = '"+name+"' WHERE emp_id = " + id;
					pst = con.prepareStatement(query);
					rs = pst.executeUpdate();
					System.out.println(rs);	
				} catch (SQLException e) {
					e.printStackTrace();
				}
			} catch (ClassNotFoundException e) {
				e.printStackTrace();
			}
		break;	
		}
	}

}
