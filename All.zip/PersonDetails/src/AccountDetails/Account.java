package AccountDetails;

public class Account {
	long accNum;
	double balance;
	Person accholder;
	public void deposit() {
		
	}
	public void withdraw() {
		
	}
	public double getBalance() {
		return accNum;
		
	}
	public long getAccNum() {
		return accNum;
	}
	public void setAccNum(long accNum) {
		this.accNum = accNum;
	}
	public Person getAccholder() {
		return accholder;
	}
	public void setAccholder(Person accholder) {
		this.accholder = accholder;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
