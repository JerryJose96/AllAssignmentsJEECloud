package AccountDetails;

public class Person {
	String name;
	float age;
	public Person() {
		this.name = "";
		this.age = 18;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public float getAge() {
		return age;
	}
	public void setAge(float age) {
		this.age = age;
	}
}
