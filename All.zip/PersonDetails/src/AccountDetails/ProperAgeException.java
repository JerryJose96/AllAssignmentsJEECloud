package AccountDetails;

class AgeException extends Exception {
	public AgeException() {
	}
	public String toString() {
		return "Age is above 15!";
	}


}

public class ProperAgeException {
	static void checkAge(float f) throws AgeException  {
		if (f>15) {
			throw new AgeException();
		}
	}

	public static void main(String[] args) {
		Person p1 = new Person();
		try {
			checkAge(p1.getAge());
		}
		catch(AgeException e) {
			System.out.println(e);
		}

	}

}
