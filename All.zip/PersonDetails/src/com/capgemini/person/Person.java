package com.capgemini.person;

import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;

public class Person {
		String firstName;
		String lastName;
		char gender;
		String dob;
		public Person() {
		}
		public String getDob() {
			return dob;
		}
		public void setDob(int age) {
			this.dob = dob;
		}
		public Person(String first,String last,char g,String dob) {
			this.firstName = first;
			this.lastName = last;
			this.gender = g;
			this.dob = dob;
		}
		public String getFirstName() {
			return firstName;
		}
		public void setFirstName(String firstName) {
			this.firstName = firstName;
		}
		public String getLastName() {
			return lastName;
		}
		public void setLastName(String lastName) {
			this.lastName = lastName;
		}
		public String getGender() {
			return String.valueOf(this.gender);
		}
		public void setGender(char gender) {
			this.gender = gender;
		}
		public int calculateAge(LocalDate date) {
			Period p = date.until(LocalDate.now());
			return p.getYears();
		}
		public String getFullName(String fname,String lname) {
			return fname+ " " +lname;
		}
		public static void main(String[] args) {
			Person p1 = new Person("Jerry","Jose",'M',"17/04/1996");
			System.out.println(p1.getFullName(p1.getFirstName(), p1.getLastName()));
			DateTimeFormatter format = DateTimeFormatter.ofPattern("dd/MM/yyyy");
			LocalDate date = LocalDate.parse(p1.getDob(),format);
			int yr = p1.calculateAge(date);
			System.out.println(yr);
		}

}
