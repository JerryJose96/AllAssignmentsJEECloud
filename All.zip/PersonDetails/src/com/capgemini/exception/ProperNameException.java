package com.capgemini.exception;
import java.lang.Exception;
import com.capgemini.person.Person;


class NameException extends Exception {
	public NameException() {
	}
	public NameException(String args) {
		super(args);
	}
		public String toString() {
			return "First Name or Last Name or both are empty!";
		}


}
public class ProperNameException{
	static void checkName(String first, String last) throws NameException  {
		if (first.equals("") && last.equals("")) {
			throw new NameException();
		}
	}

	public static void main(String[] args) {
		Person p1 = new Person();
		try {
			checkName(p1.getFirstName(),p1.getLastName());
		}
		catch(NameException e) {
			System.out.println(e);
		}
	}

}
