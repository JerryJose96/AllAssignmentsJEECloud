package com.cg.eis.exception;

import com.cg.eis.bean.Employee;

  public class EmployeeException extends Exception {
	public EmployeeException() {
	}
	public String toString() {
		return "Salary is below 3000!";
	}

	public static  void checkEmp(double f){
		if (f<3000) {
			//throw new EmpException();
			throw new RuntimeException();
		}
	}
	//the main function is commented to test this in another project
	//public static void main(String[] args) {
		//Employee p1 = new Employee();
		//try {
			//checkEmp(p1.getSalary());
		//}
		//catch(EmployeeException e) {
		//	System.out.println(e);
		//}

	}


