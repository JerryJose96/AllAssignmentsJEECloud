package dateandtime;

import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;

import com.capgemini.person.Person;

public class Age {

	public static void calculateAge(LocalDate date) {
		Period p = date.until(LocalDate.now());
		System.out.println(p.getYears());
	}
	public static void getFullName(String fname,String lname) {
		System.out.println(fname + " " + lname);
	}
	public static void main(String[] args) {
		Person p1 = new Person("Kiki","DoYouLoveMe", 'F', "17/04/1996");
		DateTimeFormatter format = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		LocalDate date = LocalDate.parse(p1.getDob(),format);
		calculateAge(date);
	}

}
