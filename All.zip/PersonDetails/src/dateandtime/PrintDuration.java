package dateandtime;

import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class PrintDuration {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter date1 in format: dd/MM/yyyy");
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		String date1 = sc.nextLine();
		System.out.println("Enter date2 in format: dd/MM/yyyy");
		String date2 = sc.nextLine();
		LocalDate Date1 = LocalDate.parse(date1,formatter);
		LocalDate Date2 = LocalDate.parse(date2,formatter);
		
		Period period = Date1.until(Date2);
		System.out.println("Days:"+ period.getDays());
		System.out.println("Months:"+period.getMonths());
		System.out.println("Years:"+ period.getYears());
	}

}
