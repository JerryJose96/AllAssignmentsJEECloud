package dateandtime;

import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class Warranty {
	static void Calculate (LocalDate date1, long months, long years) {
		date1 = date1.plusMonths(months);
		date1 = date1.plusYears(years);
		System.out.println("The final date is" + date1); 
	}
	public static void main(String[] args) {
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		System.out.println("Enter duration in dd/MM/yyyy format");
		Scanner sc = new Scanner(System.in);
		String purchaseDate = sc.nextLine();
		System.out.println("Enter warranty in months and years");
		long warrantyMonths = sc.nextLong();
		long warrantyYears = sc.nextLong();
		LocalDate date1 = LocalDate.parse(purchaseDate,formatter);
		Calculate(date1,warrantyMonths,warrantyYears);
	}

}
