package dateandtime;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class PrintDate {

	public static void main(String[] args) {
		DateTimeFormatter format = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter date in dd/MM/yyyy format:");
		String date = sc.nextLine();
		
		LocalDate eDate = LocalDate.parse(date,format);
		System.out.println("The entered date is: " + eDate);
		
		System.out.println(LocalDate.now());
	}

}
