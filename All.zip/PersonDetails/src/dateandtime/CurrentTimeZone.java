package dateandtime;

import java.time.Month;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.Scanner;

public class CurrentTimeZone {

	static void calculate(String zone) {
		ZonedDateTime userZone = ZonedDateTime.now(ZoneId.of(zone));
		Month month = userZone.getMonth();
		int day = userZone.getDayOfMonth();
		int year = userZone.getYear();
		System.out.println("The current Date of " + zone + " zone is: " + month.getValue() + "/" +day + "/"+year);
		int hour = userZone.getHour();
		int minutes = userZone.getMinute();
		int seconds = userZone.getSecond();
		System.out.println("The current Time of " + zone + " zone is: " + hour + ":" +minutes + ":"+seconds);
	}
	public static void main(String[] args) {
		System.out.println("Enter the zone ID eg. America/New_York, Europe/London, Asia/Tokyo, US/Pacific, Africa/Cairo, Australia/Sydney etc.");
		Scanner sc = new Scanner(System.in);
		String zone = sc.nextLine();
		calculate(zone);
	}

}
