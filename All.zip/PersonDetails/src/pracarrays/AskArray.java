package pracarrays;

import java.util.Scanner;

public class AskArray {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the no. of emps:");
		int empCount = sc.nextInt();
		Employee emp[] = new Employee[empCount];
		
		System.out.println("Enter the details of the employee");
		
		
		for(int c = 0; c < emp.length; c++) {
			System.out.println("Enter id of Emp" + c);
			int id = sc.nextInt();
			System.out.println("Enter the name of the emp");
			String name = sc.next();
			System.out.println("Enter the salary");
			float sal = sc.nextFloat();
			emp[c] = new Employee(id,name,sal);
		}
		
		for (int c = 0; c < emp.length; c++) {
			System.out.println(emp[c]);
		}
	}
	
}
