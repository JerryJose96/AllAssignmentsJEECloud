package pracarrays;

public class TestVarArgsDemo {

	public int add (int ...nums) {
		int sum = 0;
		for (int calc:nums) {
			sum = sum + calc;
		}
		return sum;
	}
	
	public static void main(String[] args) {
		TestVarArgsDemo obj1 = new TestVarArgsDemo();
		System.out.println("Addition of Number : " + obj1.add(7,8,9,10));

	}

}
