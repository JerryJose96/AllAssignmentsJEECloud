import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;

public class TestStreamAPIDemo {

	public static void main(String[] args) {
		List<Integer> intList = Arrays.asList(1,1,2,3,2,4);
		Stream <Integer>intListStream = intList.stream();
		
		intListStream.
		filter(num->num>10).
		forEach(num->System.out.println(num));
		
		
		System.out.println("*********Print Distinct************");
		intList.stream().
		distinct().forEach(System.out::println);
		
		System.out.println("*****************************0******");
		List<String> cityList=
				Arrays.asList("Pune","","Mumbai","Delhi","Noida","");
		cityList.stream().map(str->str.length()).
		forEach(System.out::println);
	}

}
