import java.util.HashSet;
import java.util.Iterator;
import java.util.TreeSet;

import pracarrays.Employee;

public class TestTreeSetEmpDemo {

	public static void main(String[] args) {
		TreeSet<Employee> empSet  = new TreeSet<Employee>();
		Employee e1 = new Employee(1,"Jerry",9999.0F);
		Employee e2 = new Employee(1,"Jerry",9999.0F);
		Employee e3 = new Employee(2,"Jai",9999.0F);
		Employee e4 = new Employee(4,"Jojo",9999.0F);
		
		empSet.add(e1);
		empSet.add(e2);
		empSet.add(e3);
		empSet.add(e4);
		
		Iterator<Employee> it = empSet.iterator();
		while(it.hasNext()) {
			System.out.println("Entry: " + it.next());
		}

	}

}
