import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class TestHashMapDemo {

	public static void main(String[] args) {
		HashMap<Long,String> directory = new HashMap<Long,String>();
		directory.put(3777775555L, "jerry");
		directory.put(7777775559L, "bai");
		directory.put(7777775556L, "raju");
		directory.put(7777775558L, "kiki");
		directory.put(7777775554L, "do");
		directory.put(7777775552L, "you");
		directory.put(7777775554L, "love");
		directory.put(7777775554L, "me");
		System.out.println(directory);
		System.out.println("*****Print Entries********");
		Set<Map.Entry<Long, String>> mapSet = directory.entrySet();
		Iterator<Map.Entry<Long,String>> it = mapSet.iterator();
		while(it.hasNext()) {
			Map.Entry<Long, String> entry= it.next();
			System.out.println("Key : " + entry.getKey() + " Name : " + entry.getValue());

		}
		System.out.println("*****Print Keys********");
		Set<Long> keySet = directory.keySet();
		Iterator<Long> itera = keySet.iterator();
		while(itera.hasNext()) {
			Long entry= itera.next();
			System.out.println("Key : " + entry);

		}
		System.out.println("*****Print Values********");
		Collection<String> valueSet = directory.values();
		Iterator<String> iterator = valueSet.iterator();
		while(iterator.hasNext()) {
			String ent= iterator.next();
			System.out.println("values : " + ent);

		}
	}

}
