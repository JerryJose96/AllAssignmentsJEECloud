import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class EvenNumbers {

	public static void main(String[] args) {
		File file = new File("D://Jerry Jose/Eight/Numbers");
		FileReader fis = null;
		BufferedReader br = null;
		Scanner sc = null;
		try {
			//fis = new FileReader(file);
			//br = new BufferedReader(fis);
			sc = new Scanner(file);
			String line = sc.nextLine();
			String[] parts = line.split(",");
			//int[] ints = new int[parts.length];
			for (int i = 0; i < parts.length; i++) {
			    if((Integer.parseInt(parts[i])%2)==0) {
			    	System.out.println(Integer.parseInt(parts[i]));
			    }
			}
			
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
