import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class EightOne {

	public static void main(String[] args) {
		File file = new File("D://Jerry Jose/Eight/Sample");
		FileReader fis = null;
		FileWriter fw = null;
		BufferedReader br = null;
		BufferedWriter bw = null;
		StringBuilder sb = null;
		try {
			fis = new FileReader(file);
			br = new BufferedReader(fis);
			fw = new FileWriter("D://Jerry Jose/Eight/out");
			bw = new BufferedWriter(fw);
			String line = br.readLine();
			//System.out.println(line);
			sb = new StringBuilder();
			while(line!=null) {
				sb.append(line);
				line = br.readLine();
			}
			System.out.println(sb);
			sb = sb.reverse();
			String rev = new String(sb);
			bw.write(rev);
			bw.flush();
			
			File file1 = new File("D://Jerry Jose/Eight/out");
			fis = new FileReader(file1);
			br = new BufferedReader(fis);
			fw = new FileWriter("D://Jerry Jose/Eight/Sample");
			bw = new BufferedWriter(fw);
			String input = br.readLine();
				bw.write(input);
				bw.flush();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
