package com.capgemini.service;

import java.sql.SQLException;
import java.util.ArrayList;

import com.capgemini.bean.BookingBean;
import com.capgemini.bean.TrainBean;
import com.capgemini.exception.BookingException;

public interface TrainService {
	ArrayList<TrainBean> retrieveTrainDetails() throws BookingException;
	int bookTicket(BookingBean bookingBean) throws BookingException;
	boolean validateCustId(String custId) throws BookingException;
	boolean validateTrainId(int trainId) throws BookingException, SQLException;
	boolean validateSeatsAvailable(int seats,int trainId) throws BookingException;
}
