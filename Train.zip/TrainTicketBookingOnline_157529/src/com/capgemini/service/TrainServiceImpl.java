package com.capgemini.service;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.regex.Pattern;

import com.capgemini.bean.BookingBean;
import com.capgemini.bean.TrainBean;
import com.capgemini.dao.TrainDaoImpl;
import com.capgemini.exception.BookingException;
import com.capgemini.util.DBUtil;

public class TrainServiceImpl implements TrainService{
	TrainDaoImpl tDI = null;
	int availableSeats;
	int d;
	public TrainServiceImpl() {
		tDI = new TrainDaoImpl();
	}
	@Override
	public ArrayList<TrainBean> retrieveTrainDetails() throws BookingException{
		return tDI.retrieveTrainDetails();
	}

	@Override
	public int bookTicket(BookingBean bookingBean) throws BookingException {
		return tDI.bookTicket(bookingBean);
	}
	@Override
	public boolean validateCustId(String custId) throws BookingException {
		String id = "[A-Z][0-9]{6}";
		if (Pattern.matches(id, custId)) {
			return true;
		}
		else {
			throw new BookingException("The Customer ID should start with a Capital Letter followed by 6 digits.");
		}

	}
	@Override
	public boolean validateTrainId(int trainId) throws BookingException, SQLException {
		Connection con = null;
		Statement st = null;
		ResultSet rs = null;

		try {
			con = DBUtil.getConn();
			String selectQuery = "SELECT * FROM traindetails WHERE trainid="+trainId;
			st = con.createStatement();
			rs = st.executeQuery(selectQuery);
		}
		catch(Exception e) {
			e.printStackTrace();
			throw new BookingException(e.getMessage());
		}
		//System.out.println(rs);
		if(rs.next()) {
			return true;
		}
		else {
			throw new BookingException("There is no Train with such Train ID.");

		}


	}
	@Override
	public boolean validateSeatsAvailable(int seats,int trainId) throws BookingException {
		Connection con = null;
		Statement st = null;
		ResultSet rs = null;
		try {
			con = DBUtil.getConn();
			String selectQuery = "SELECT availableseats FROM traindetails WHERE trainid="+trainId;
			st = con.createStatement();
			rs = st.executeQuery(selectQuery);
			while(rs.next()) {
				availableSeats = rs.getInt("availableseats");
			}
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		finally {
			try {
				rs.close();
				st.close();
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		if (seats>0 && seats<availableSeats) {
			return true;
		}
		else {
			throw new BookingException("Sorry No Seats Available");
		}
	}

}
