package com.capgemini.exception;

public class BookingException extends Exception{
	String msg;
	static ErrorCode code;
	public BookingException(String msg) {
		super(msg);
	}
	public BookingException(String msg,Throwable cause,ErrorCode code) {
		super(msg,cause);
		this.code = code;
	}
}
