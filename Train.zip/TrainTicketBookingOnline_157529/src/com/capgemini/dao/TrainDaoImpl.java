package com.capgemini.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import org.apache.log4j.PropertyConfigurator;

import com.capgemini.bean.BookingBean;
import com.capgemini.bean.TrainBean;
import com.capgemini.exception.BookingException;
import com.capgemini.util.DBUtil;

public class TrainDaoImpl implements TrainDao{
	Connection con = null;
	Statement st = null;
	PreparedStatement pst = null;
	ResultSet rs = null;
	int seats,bookingId;
	public TrainDaoImpl() {
		PropertyConfigurator.configure("resources/log4j.properties");
	}

	@Override
	public ArrayList<TrainBean> retrieveTrainDetails() throws BookingException{
		ArrayList<TrainBean> trainList = null;
		try {
			con = DBUtil.getConn();
			trainList = new ArrayList<TrainBean>();
			String selectQuery = "SELECT * FROM traindetails";
			st = con.createStatement();
			rs = st.executeQuery(selectQuery);
			while(rs.next()) {
				trainList.add(new TrainBean(rs.getInt("trainId"),rs.getString("trainType"),
						rs.getString("fromStop"),rs.getString("toStop"),rs.getInt("fare"),
						rs.getInt("availableSeats"),rs.getDate("dateOfJourney").toLocalDate()));
			}
		}catch(Exception e) {
			throw new BookingException(e.getMessage());
		}
		finally {
			try {
				st.close();
				rs.close();
				con.close();
			}catch(SQLException e) {
				throw new BookingException(e.getMessage());
			}
		}
		return trainList;
	}

	@Override
	public int bookTicket(BookingBean bookingBean) throws BookingException {
		int data;
		try {
			con = DBUtil.getConn();
			String insertQuery = "INSERT INTO bookingdetails VALUES(booking_id_seq.nextval,?,?,?)";
			pst = con.prepareStatement(insertQuery);
			pst.setString(1, bookingBean.getCustId());
			pst.setInt(2, bookingBean.getTrainId());
			pst.setInt(3, bookingBean.getNoOfSeat());
			pst.executeUpdate();
			//updating no. of seats
			String searchQuery = "SELECT availableseats FROM traindetails WHERE trainid="+bookingBean.getTrainId();
			st = con.createStatement();
			rs = st.executeQuery(searchQuery);
			while(rs.next()) {
				seats = rs.getInt("availableseats");
			}
			seats = seats - bookingBean.getNoOfSeat();
			String insertQuery1 = "UPDATE traindetails SET availableseats=? WHERE trainid=?";
			pst = con.prepareStatement(insertQuery1);
			pst.setInt(1, seats);
			pst.setInt(2, bookingBean.getTrainId());
			pst.executeUpdate();
			//returning bookingID
			String searchQuery1 = "SELECT bookingid FROM bookingdetails WHERE bookingid="+bookingBean.getBookingId();
			st = con.createStatement();
			rs = st.executeQuery(searchQuery);
			//while(rs.next()) {
			//	bookingId = rs.getInt("bookingid");
			//}
			return bookingBean.getBookingId();
		}
		catch(Exception e) {
			e.printStackTrace();
			throw new BookingException(e.getMessage());		
		}
	}

}
