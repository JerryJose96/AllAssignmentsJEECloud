package com.capgemini.client;

import java.util.ArrayList;
import java.util.Scanner;

import com.capgemini.bean.BookingBean;
import com.capgemini.bean.TrainBean;
import com.capgemini.exception.BookingException;
import com.capgemini.service.TrainServiceImpl;

public class MainClient {
	static TrainServiceImpl trainService = null;
	static Scanner sc = null;

	public static void main(String[] args) {
		System.out.println("***********Welcome to Train Ticket Online Booking***********");
		sc = new Scanner(System.in);
		trainService = new TrainServiceImpl();
		int choice = 0;
		System.out.println("Enter:\n1. Book Ticket\n2. Exit");
		choice = sc.nextInt();
		switch(choice) {
		case 1: bookTicket();break;
		case 2: System.exit(1);break;	
		default: System.exit(1);
		}
	}

	private static void bookTicket() {
		Scanner sc1 = new Scanner(System.in);
		ArrayList<TrainBean> trainList = new ArrayList<TrainBean>();
		try {
			trainList = trainService.retrieveTrainDetails();
			System.out.println("\tTRAIN ID \tTRAIN TYPE \tFROM \tTO \tSEATS \tDATE");
			for(TrainBean train:trainList) {
				System.out.println(train.getTrainId()+"\t"+
						train.getTrainType()+"\t"+train.getFromStop()+"\t"+
						train.getToStop()+"\t"+train.getAvailableSeats()+"\t"+
						train.getDateOfJourney());
			}
			System.out.println("Enter Customer ID please.");
			String custId = sc1.nextLine();
			if(trainService.validateCustId(custId)) {
				System.out.println("Enter Train ID please.");
				int trainId = sc.nextInt();
				if(trainService.validateTrainId(trainId)) {
					System.out.println("Enter no. of seats please.");
					int Seats = sc.nextInt();
					if(trainService.validateSeatsAvailable(Seats, trainId)) {
						BookingBean bookingBean = new BookingBean(1,custId,trainId,Seats);
						int done = trainService.bookTicket(bookingBean);
						if(done!=0) {
							System.out.println("Thankyou, Your booking id is: "+ done);
						}
					}
				}
			}
		} catch (BookingException e) {
			e.printStackTrace();
		}

	}

}
