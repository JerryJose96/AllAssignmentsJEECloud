package com.capgemini.bean;

import java.time.LocalDate;

public class TrainBean {
	private int trainId;
	private String trainType;
	private LocalDate dateOfJourney;
	private String fromStop,toStop;
	private int availableSeats,fare;
	public TrainBean() {
	}
	public TrainBean(int trainId, String trainType, String fromStop, String toStop, int fare,
			int availableSeats,LocalDate dateOfJourney) {
		super();
		this.trainId = trainId;
		this.trainType = trainType;
		this.dateOfJourney = dateOfJourney;
		this.fromStop = fromStop;
		this.toStop = toStop;
		this.availableSeats = availableSeats;
		this.fare = fare;
	}
	public int getTrainId() {
		return trainId;
	}
	public void setTrainId(int trainId) {
		this.trainId = trainId;
	}
	public String getTrainType() {
		return trainType;
	}
	public void setTrainType(String trainType) {
		this.trainType = trainType;
	}
	public LocalDate getDateOfJourney() {
		return dateOfJourney;
	}
	public void setDateOfJourney(LocalDate dateOfJourney) {
		this.dateOfJourney = dateOfJourney;
	}
	public String getFromStop() {
		return fromStop;
	}
	public void setFromStop(String fromStop) {
		this.fromStop = fromStop;
	}
	public String getToStop() {
		return toStop;
	}
	public void setToStop(String toStop) {
		this.toStop = toStop;
	}
	public int getAvailableSeats() {
		return availableSeats;
	}
	public void setAvailableSeats(int availableSeats) {
		this.availableSeats = availableSeats;
	}
	public int getFare() {
		return fare;
	}
	public void setFare(int fare) {
		this.fare = fare;
	}
	
}
